let tamanhoFonte = 1;

document.getElementById("btnAumentar").addEventListener("click", () => {
  tamanhoFonte += 0.1;
  document.body.style.fontSize = `${tamanhoFonte}rem`;
});

document.getElementById("btnContraste").addEventListener("click", () => {
  document.body.classList.toggle("alto-contraste");
});